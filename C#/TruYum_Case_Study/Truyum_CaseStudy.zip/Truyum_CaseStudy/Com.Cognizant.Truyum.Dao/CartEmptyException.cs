﻿using System;

namespace Com.Cognizant.Truyum.Dao
{
    class CartEmptyException : Exception
    {
        private static readonly string DefaultMessage = "Cart is empty please add !!";

        public CartEmptyException() : base(DefaultMessage) { }
        public CartEmptyException(string message) : base(message)
        {

        }
    }
}
