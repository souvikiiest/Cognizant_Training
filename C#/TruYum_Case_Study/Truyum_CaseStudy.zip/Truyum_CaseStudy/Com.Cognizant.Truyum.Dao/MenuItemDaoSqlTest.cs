﻿namespace Com.Cognizant.Truyum.Dao
{
    class MenuItemDaoSqlTest
    {
        public static void Main(string[] args)
        {

        }
        public static void TestGetMenuItemListAdmin()
        {

        }
        public static void TestGetMenuItemListCustomer()
        {

        }
        public static void TestModifyMenuItem()
        {

        }
        public static void TestGetMenuItem()
        {

        }

    }
}
