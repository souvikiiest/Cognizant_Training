

 function findName(customers:[number,string][]):string
{
    var max:number=customers[0][1].length;
    var maxName:string=customers[0][1];
    for(var i=1;i<customers.length;i++)
    {
        if(customers[i][1].length>max)
        {
            max=customers[i][1].length;
            maxName=customers[i][1];
        }
    }
    return maxName;
    
}export=findName;
